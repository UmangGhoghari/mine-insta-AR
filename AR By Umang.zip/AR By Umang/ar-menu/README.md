# AR Menu - MindAR.js Web App

A complete Augmented Reality menu experience using MindAR.js and A-Frame. Point your mobile camera at a printed menu card to see a floating digital menu image appear on top of it.

## 📁 Project Structure

```
ar-menu/
├── index.html
├── targets.mind          (Add this file manually)
├── assets/
│   ├── menu-image.jpg    (Add this file manually)
│   └── loading.gif       (Optional)
└── README.md
```

## 🚀 Quick Start

### 1. Replace targets.mind File

The `targets.mind` file is the MindAR image tracking database file that contains your menu card image data.

**How to create targets.mind:**

1. Go to [MindAR Image Compiler](https://hiukim.github.io/mind-ar-js-doc/tools/compile)
2. Upload your menu card image (the physical card you will print)
3. Click "Compile" to generate the `.mind` file
4. Download the file and rename it to `targets.mind`
5. Place it in the `ar-menu/` directory (same level as index.html)

**Tips for best tracking:**
- Use a high-contrast image with distinctive features
- Avoid plain text-only cards
- Include logos, patterns, or unique visual elements
- Image should be at least 500x500 pixels
- Keep the aspect ratio similar to your printed card

### 2. Replace menu-image.jpg File

This is the floating AR image that will appear when the camera detects your menu card.

**How to add your menu image:**

1. Prepare your digital menu image (JPG format recommended)
2. Recommended size: 1000x1400 pixels (to match the 1:1.4 aspect ratio in code)
3. Name it `menu-image.jpg`
4. Place it in the `ar-menu/assets/` directory

**Image specifications:**
- Format: JPG or PNG
- Aspect ratio: 1:1.4 (width:height)
- File size: Keep under 2MB for faster loading
- Resolution: 1000x1400 pixels recommended

## 🌐 Deploy on GitHub Pages

### Method 1: GitHub Pages (Recommended)

1. **Create a GitHub repository**
   - Go to github.com and create a new repository
   - Name it something like `ar-menu`
   - Make it public (for easier sharing)

2. **Upload your files**
   - Click "Upload files" on the repository page
   - Upload the entire `ar-menu` folder contents
   - Commit the changes

3. **Enable GitHub Pages**
   - Go to repository Settings → Pages
   - Under "Source", select "Deploy from a branch"
   - Select "main" branch and "/ (root)" folder
   - Click "Save"

4. **Get your URL**
   - Wait 1-2 minutes for deployment
   - Your URL will be: `https://yourusername.github.io/ar-menu/`

### Method 2: Direct File Opening (Testing Only)

You can also test by opening `index.html` directly in a browser:
- Double-click `index.html` to open it
- **Note:** Camera access may be blocked in some browsers due to security restrictions
- For production, always use HTTPS (GitHub Pages provides this automatically)

## 📱 How to Test

1. **Deploy the app** using GitHub Pages (see above)
2. **On your mobile device:**
   - Open the GitHub Pages URL in Chrome or Safari
   - Allow camera permission when prompted
   - Wait for the loading screen to disappear
   - Point your camera at your printed menu card
3. **The AR menu image should appear** floating on top of the card

## 🖨️ Printing the Menu Card

1. Use the same image you uploaded to MindAR compiler
2. Print it on paper or card stock
3. Recommended size: 10cm x 14cm (or any size that maintains aspect ratio)
4. Ensure good lighting for best tracking

## 📱 QR Code Generation

Create a QR code to easily share your AR menu:

### Free QR Code Generators:
- [QR Code Generator](https://www.qrcode-generator.com/)
- [QRCode Monkey](https://www.qrcodemonkey.com/)
- [GoQR.me](https://goqr.me/)

### Steps:
1. Copy your GitHub Pages URL (e.g., `https://yourusername.github.io/ar-menu/`)
2. Paste it into any QR code generator
3. Download the QR code image
4. Print it and place it near your physical menu card

### Usage:
- Customers scan the QR code with their phone camera
- They're directed to your AR menu app
- They point at the menu card to see the digital menu

## 🔧 Customization

### Change AR Image Size
In `index.html`, modify the a-image attributes:
```html
<a-image
    src="#menu-image"
    width="1"        <!-- Change width -->
    height="1.4"     <!-- Change height -->
    position="0 0 0"
    rotation="-90 0 0">
</a-image>
```

### Change Loading Text
In `index.html`, modify the loading text:
```html
<div id="loading-text">📷 Camera ko Menu Card pe point karo</div>
```

### Add Multiple Targets
To track multiple menu cards:
1. Compile multiple images in MindAR compiler
2. Add additional target entities in index.html:
```html
<a-entity id="target-1" mindar-image-target="targetIndex: 1">
    <a-image src="#menu-image-2" width="1" height="1.4"></a-image>
</a-entity>
```

## 🛠️ Tech Stack

- **MindAR.js v1.2.2** - Image tracking AR library
- **A-Frame v1.5.0** - WebVR framework
- **Pure HTML/CSS/JS** - No build tools required
- **GitHub Pages** - Free HTTPS hosting

## ⚠️ Troubleshooting

### Camera not working
- Ensure you're using HTTPS (GitHub Pages provides this)
- Check browser permissions for camera access
- Try Chrome or Safari (best support)
- Clear browser cache and reload

### AR not detecting menu card
- Ensure good lighting (avoid dark environments)
- Hold the menu card steady
- Keep the card within camera frame
- Check that your targets.mind file matches your printed card

### Image not appearing
- Verify menu-image.jpg exists in assets folder
- Check file path in index.html
- Ensure image file is not corrupted
- Check browser console for errors

### Loading screen stuck
- Check browser console for errors (F12 → Console)
- Verify targets.mind file is present
- Ensure all files are uploaded correctly to GitHub Pages

## 📄 License

Free to use for personal and commercial projects.

## 🤝 Support

For MindAR.js documentation: https://hiukim.github.io/mind-ar-js-doc/
For A-Frame documentation: https://aframe.io/docs/
